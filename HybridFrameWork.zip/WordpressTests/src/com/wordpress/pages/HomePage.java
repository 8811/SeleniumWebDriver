package com.wordpress.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.wordpress.utils.PropertyUtil;

public class HomePage {
	WebDriver driver;
	PropertyUtil propUtil;
	

	public HomePage(WebDriver driver) {
		this.driver = driver;
		propUtil = new PropertyUtil("./resources/object.properties");
	}

	public void clickLoginLink() {
		String value = propUtil.getPropertyValue("home_loginlink_linktext");
		WebElement loginLinkElement = driver.findElement(By.linkText(value));
		loginLinkElement.click();
	}
}
