package com.wordpress.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.wordpress.utils.PropertyUtil;

public class LoginPage {

	WebDriver driver;
	PropertyUtil propUtil;
	
	public LoginPage(WebDriver driver)
	{
		this.driver = driver;
		propUtil = new PropertyUtil("./resources/object.properties");
	}
	
	
	public void setUserName(String userName)
	{
		String value = propUtil.getPropertyValue("login_username_id");
		WebElement userTextElement  = driver.findElement(By.id(value));
		userTextElement.sendKeys(userName);
	}
	
	public void setPassword(String passWord)
	{
		String value = propUtil.getPropertyValue("login_password_id");
		WebElement pwdTextElement  = driver.findElement(By.id(value));
		pwdTextElement.sendKeys(passWord);
	}
	
	
	public void clickOnLoginButton()
	{
		String value = propUtil.getPropertyValue("login_loginbtn_id");
		WebElement submitBtnElement = driver.findElement(By.id(value));
		submitBtnElement.click();
	}
	
	
}
