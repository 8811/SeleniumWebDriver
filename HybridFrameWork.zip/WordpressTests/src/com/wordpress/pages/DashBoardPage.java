package com.wordpress.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.wordpress.utils.PropertyUtil;

public class DashBoardPage 
{
	WebDriver driver;
	PropertyUtil propUtil = new PropertyUtil("./resources/object.properties");
	public DashBoardPage(WebDriver driver)
	{
		this.driver = driver;
	}
	
	
	public void clickOnProfileIcon()
	{
		String value = propUtil.getPropertyValue("dashboard_profile_icon_xpath");
		WebElement element = driver.findElement(By.xpath(value));
		element.click();
	}
}
