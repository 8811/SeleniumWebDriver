package com.wordpress.utils;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;


public class PropertyUtil 
{
	String fileName;	
	
	Properties properties;

	public PropertyUtil(String fileName)
	{
		this.fileName = fileName;
		load();
	}
	
	
	public void load()
	{
		properties = new Properties();
		FileReader reader;
		try {
			reader = new FileReader(fileName);
			properties.load(reader);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public String getPropertyValue(String key)
	{
		
		String value = properties.getProperty(key);
		return value;
	}
}
