package com.wordpress.utils;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class ExcelUtil 
{
	String fileName;
	int sheetNo;
	HSSFWorkbook workbook;
	HSSFSheet sheet;
	
	
	public ExcelUtil(String fileName,int sheetNo)
	{
		this.fileName = fileName;
		this.sheetNo = sheetNo;
		load();
	}
	
	
	public void load()
	{
		try {
			FileInputStream file = new FileInputStream(fileName);
			workbook = new HSSFWorkbook(file);
			sheet = workbook.getSheetAt(sheetNo);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	public String getCellValue(int row,int col)
	{
		HSSFRow rowData = sheet.getRow(row);
		HSSFCell cell = rowData.getCell(col);
		return cell.toString();
	}
	
	
	public int getNumberOfRows()
	{
		int lastRowNum = sheet.getLastRowNum();
		return lastRowNum;
	}
}
