package com.wordpress.tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.wordpress.pages.HomePage;
import com.wordpress.pages.LoginPage;
import com.wordpress.utils.ExcelUtil;


public class WordpressLoginTest {
	
	WebDriver driver;
	HomePage hPage;
	LoginPage lPage;
	
	@BeforeMethod
	public void setUp()
	{
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://wordpress.com/");
		
		//Intialize Page classes
		hPage = new HomePage(driver);
		lPage = new LoginPage(driver);
		
	}
	
	@AfterMethod
	public void tearDown()
	{
		driver.close();
	}
	
	@Test
	public void testLoginWithInvalidUserNameAndPassword()
	{
		ExcelUtil excelUtil = new ExcelUtil("./resources/login.xls", 0);
		int count = excelUtil.getNumberOfRows();
		hPage.clickLoginLink();
		for(int i=1;i<=count;i++)
		{
			String userName = excelUtil.getCellValue(i, 0);
			String passWord = excelUtil.getCellValue(i, 1);
			String expectedOp = excelUtil.getCellValue(i, 2);
			
			lPage.setUserName(userName);
			lPage.setPassword(passWord);
			lPage.clickOnLoginButton();
			String pageSource = driver.getPageSource();
			boolean result  = pageSource.contains(expectedOp);
			Assert.assertTrue(result, "Exepecting error meessage, but not found");
		}
		
	}
	

}
