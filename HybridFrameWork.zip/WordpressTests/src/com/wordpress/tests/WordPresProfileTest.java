package com.wordpress.tests;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.wordpress.pages.DashBoardPage;
import com.wordpress.pages.HomePage;
import com.wordpress.pages.LoginPage;
import com.wordpress.pages.ProfilePage;

public class WordPresProfileTest 
{
		
	LoginPage loginPage;
	HomePage homePage;
	ProfilePage profilePage;
	DashBoardPage dashBoardPage;
	WebDriver driver;
	
	
	@BeforeMethod
	public void setUp()
	{
		driver = new FirefoxDriver();		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("http://www.wordpress.com");
		loginPage = new LoginPage(driver);
		homePage = new HomePage(driver);
		profilePage = new ProfilePage(driver);
		dashBoardPage = new DashBoardPage(driver);
	}
	
	@Test
	public void testMyProfileWithValidDetails() throws Exception
	{
		homePage.clickLoginLink();
		loginPage.setUserName("sudheerkumar.gv@gmail.com");
		loginPage.setPassword("abcxyz123");
		loginPage.clickOnLoginButton();
		Thread.sleep(1*1000);
				
		dashBoardPage.clickOnProfileIcon();
		profilePage.setFirstName("sudheer");
		profilePage.setLastName("g");
		profilePage.setAboutMe("This is sudheer"+System.currentTimeMillis());
		profilePage.clickSave();
		Thread.sleep(5*1000);
		String note = profilePage.getTextOnSaveNote();
		Assert.assertEquals(note, "Settings saved successfully!");
	}
	
	@AfterMethod
	public void tearDown()
	{
		driver.close();
	}
}
